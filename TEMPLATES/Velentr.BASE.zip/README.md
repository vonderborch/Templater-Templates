# Velentr.BASE

![Screenshot](https://github.com/vonderborch/Velentr.BASE/blob/main/logo.png?raw=true)

[DESCRIPTION]

## Installation

### Nuget

[![NuGet version (Velentr.BASE)](https://img.shields.io/nuget/v/Velentr.BASE.svg?style=flat-square)](https://www.nuget.org/packages/Velentr.BASE/)

The recommended installation approach is to use the available nuget package: [Velentr.BASE](https://www.nuget.org/packages/Velentr.BASE/)

### Clone

Alternatively, you can clone this repo and reference the Velentr.BASE project in your project.

## Features

## Development

1. Clone or fork the repo
2. Create a new branch
3. Code!
4. Push your changes and open a PR
5. Once approved, they'll be merged in
6. Profit!

## Future Plans

See list of issues under the Milestones: https://github.com/vonderborch/Velentr.BASE/milestones
