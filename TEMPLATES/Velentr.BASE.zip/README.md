# Velentr.BASE
A library

# Installation
[![NuGet version (Velentr.BASE)](https://img.shields.io/nuget/v/Velentr.BASE.svg?style=flat-square)](https://www.nuget.org/packages/Velentr.BASE/)

A nuget package is available: [Velentr.BASE](https://www.nuget.org/packages/Velentr.BASE/)

# Future Plans
See list of issues under the Milestones: https://github.com/vonderborch/Velentr.BASE/milestones
