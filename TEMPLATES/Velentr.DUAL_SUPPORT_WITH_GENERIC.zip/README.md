# Velentr.DUAL_SUPPORT_WITH_GENERIC
A library

# Installation
A generic nuget package is available: [![NuGet version (Velentr.DUAL_SUPPORT_WITH_GENERIC)](https://img.shields.io/nuget/v/Velentr.DUAL_SUPPORT_WITH_GENERIC.svg?style=flat-square)](https://www.nuget.org/packages/Velentr.DUAL_SUPPORT_WITH_GENERIC/): [Velentr.DUAL_SUPPORT_WITH_GENERIC](https://www.nuget.org/packages/Velentr.DUAL_SUPPORT_WITH_GENERIC/)

There are also nuget packages available for Monogame and FNA:
- Monogame [![NuGet version (Velentr.DUAL_SUPPORT_WITH_GENERIC.Monogame)](https://img.shields.io/nuget/v/Velentr.DUAL_SUPPORT_WITH_GENERIC.Monogame.svg?style=flat-square)](https://www.nuget.org/packages/Velentr.DUAL_SUPPORT_WITH_GENERIC.Monogame/): [Velentr.DUAL_SUPPORT.Monogame](https://www.nuget.org/packages/Velentr.DUAL_SUPPORT_WITH_GENERIC.Monogame/)
- FNA [![NuGet version (Velentr.DUAL_SUPPORT_WITH_GENERIC.FNA)](https://img.shields.io/nuget/v/Velentr.DUAL_SUPPORT_WITH_GENERIC.FNA.svg?style=flat-square)](https://www.nuget.org/packages/Velentr.DUAL_SUPPORT_WITH_GENERIC.FNA/): [Velentr.DUAL_SUPPORT.FNA](https://www.nuget.org/packages/Velentr.DUAL_SUPPORT_WITH_GENERIC.FNA/)

# Future Plans
See list of issues under the Milestones: https://github.com/vonderborch/Velentr.DUAL_SUPPORT_WITH_GENERIC/milestones
